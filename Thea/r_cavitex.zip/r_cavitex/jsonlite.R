# install.packages("jsonlite")

library(jsonlite)
library(tidyverse)
library(leaflet)

# download waze data feeds
data <- fromJSON("https://www.waze.com/row-partnerhub-api/partners/11262491165/waze-feeds/8d2cefb6-9636-402c-adb1-be2977117f2d?format=1", flatten = TRUE)

# extract alerts data
dfalerts <- as.data.frame(data$alerts)

# extract jams data
dfjams <- as.data.frame(data$jams)

# extract irregularities data
dfirregularities <- as.data.frame(data$irregularities)

# to extract and flatten coordinates
flatten_coordinates <- function(line_data) {
  coords <- line_data$x
  coords <- data.frame(
    lng = coords,
    lat = line_data$y
  )
  
  return(coords)
}

# extract and flatten JAM coordinates
dfjams_points <- dfjams %>%
  mutate(coordinates = map(line, flatten_coordinates)) %>%
  select(-line) %>%
  unnest(coordinates)

# extract and flatten IRREGULARITIES coordinates
dfirregularities_points <- dfirregularities %>%
  mutate(coordinates = map(line, flatten_coordinates)) %>%
  select(-line) %>%
  unnest(coordinates)

# create leaflet map and add marker
map_combined <- leaflet() %>%
  addTiles() %>%
  addLegend(
    "topright",
    title = "Map Legend",
    colors = c("blue", "red", "green"),
    label = c("Alerts", "Jams", "Irregulaties"),
    opacity = 1
  ) %>%
  addCircleMarkers(
    data = dfalerts,
    lng = ~location.x,
    lat = ~location.y,
    popup = ~subtype,
    color = "blue",
    radius = 6
  ) %>%
  addCircleMarkers(
    data = dfjams_points,
    lng = ~lng,
    lat = ~lat,
    color = "red",
    radius = 3
  ) %>%
  addCircleMarkers(
    data = dfirregularities_points,
    lng = ~lng,
    lat = ~lat,
    color = "green",
    radius = 3
  )

# display map and legend
map_combined