# install.packages('shiny')
# install.packages(c('tidyverse','leaflet'))
# install.packages(c('httr','jsonlite'))
# install.packages('remotes')
# remotes::install_github('JosiahParry/populartimes')

# r file
source('D:\\Codes\\r_cavitex\\google_popular_times\\get_week_of_day.R')
source('D:\\Codes\\r_cavitex\\google_popular_times\\google_popular_times.R')
source('D:\\Codes\\r_cavitex\\google_popular_times\\api.R')

library(shiny)
library(tidyverse)
library(leaflet)

# html ui
ui <- fillPage(
  tags$head(
    tags$style(
      HTML(
        'body { height: 100%; background-color: white; }',
        '.fill-25 { float: left; width: 40%; height: 100%; }',
        '.fill-75 { float: right; width: 60%; height: 100%;}',
        '#id_search { float: right; background-color: #46923C; color: white; border: 2px solid #46923C }'
      )
    )
  ),
  # left panel
  div(
    class = 'fill-25',
    # search
    div(
      style = 'padding: 10px; margin-bottom: 30px',
      h3('Google Popular Times', style = 'font-weight: bold; color: #46923C;'), # title
      uiOutput(outputId = 'id_location')
      # textInput(inputId = 'id_place_name', label = 'Place name', width = '100%'), # place name
      # textInput(inputId = 'id_address', label = 'Address', width = '100%'), # address
      # actionButton(inputId = 'id_search', label = 'Search'), # button
    ),
    # week picker
    div(
      style = 'padding: 10px;',
      uiOutput(outputId = 'id_week'),
    ),
    # graph
    imageOutput(outputId = 'id_graph')
  ),
  # right panel
  # map
  div(
    id = 'id_map_default',
    class = 'fill-75',
    leafletOutput(outputId = 'id_map', width = '100%', height = '100%')
  )
)

# html function
server <- function(input, output, session) {
  # default map view
  output$id_map <- renderLeaflet({
    leaflet(height = '100%') %>%
      addTiles() %>%
      setView(
        lng = 121.7740,
        lat = 12.8797,
        zoom = 6
      )
  })
  
  location <- get_location()
  
  if (location$status == 200) {
    output$id_location <- renderUI({
      selectInput(
        inputId = 'id_toll_plaza',
        width = '100%',
        label = 'Location',
        choices = location$location$name,
        multiple = FALSE
      )
    })
  } else {
    # empty place name
    showModal(
      modalDialog(
        title = 'Server connection',
        'No fetched location.',
        easyClose = TRUE,
        footer = div(
          modalButton('Close')
        )
      )
    )
  }
  
  # search place; show map
  observeEvent(
    input$id_toll_plaza, {
      # address <- data.frame() %>%
      #   case_when(str_detect(name, input$id_toll_plaza) ~ address)
      
      address <- get_address(input$id_toll_plaza)
      
      print(address)
    }
  )
  
  # week of the day picker
  observeEvent(
    input$id_week_of_day, {
      # get day of week
      # day_week <- weekdays(Sys.Date())
      day_number <- get_week_of_day(input$id_week_of_day)
      
      # get place information
      df_place <- popular_times_graph(
        place_name,
        place_address,
        input$id_week_of_day,
        day_number
      )
      
      # show bar graph
      output$id_graph <- renderImage(
        list(src = df_place$file, width = '100%', height = '300px'),
        deleteFile = FALSE
      )
    }
  )
}

shinyApp(ui = ui, server = server)