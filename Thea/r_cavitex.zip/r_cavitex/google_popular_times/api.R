library(httr)
library(jsonlite)

get_location <- function() {
  res <- POST('http://localhost:8000/location')
  data <- fromJSON(rawToChar(res$content))
  
  return(Vectorize(data))
}

get_address <- function(loc) {
  print(loc)
  
  params <- toJSON(list(location_name = loc), auto_unbox = TRUE)
  print(params)
  
  res <- POST(url = 'http://localhost:8000/location/address',
                add_headers('Content-Type' = 'application/x-www-form-urlencoded; charset=UTF-8',
                            'Accept' = 'application/x-www-form-urlencoded'),
                body = params
              )
  data <- fromJSON(rawToChar(res$content))
  
  return(data)
}